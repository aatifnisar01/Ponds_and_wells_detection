# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 18:50:10 2024

@author: Aatif
"""

import csv
import os
import random
from PIL import Image, ImageTk
from tkinter import Tk, Label, Radiobutton, Button, IntVar, Frame, Entry, messagebox

# Path to the folder containing all the images
image_folder = 'C:/Users/Aatif/OneDrive/Desktop/Survey/class0'

# Create a list of image paths from the folder
image_paths = [os.path.join(image_folder, f) for f in os.listdir(image_folder)]

# Keep track of the images that have already been shown
shown_images = set()

# Create the window and label for displaying the images
window = Tk()
window.title('AHI Estimation')

# Add some text to the window
welcome_label = Label(window, text='Welcome to our survey!', font=('Arial', 20))
welcome_label.pack(padx=10, pady=10)
instruction_label = Label(window, text='Please provide the following information for the displayed image:', font=('Arial', 14))
instruction_label.pack(padx=10, pady=10)

# Create a frame to hold the image
image_frame = Frame(window)
image_frame.place(relx=0.01, rely=0.18)

# Create a label for the image
label = Label(image_frame)
label.pack(fill='both', expand=True)

# Create a frame to hold the input fields
input_frame = Frame(window)
input_frame.place(relx=0.58, rely=0.23, relwidth=0.4, relheight=0.4)

# Create input fields for 'Number of Ponds', 'Correct Detection', and 'Incorrect Detection'
number_ponds_label = Label(input_frame, text='Number of Ponds:', font=('Arial', 12))
number_ponds_label.grid(row=0, column=0, padx=10, pady=10)
number_ponds_entry = Entry(input_frame)
number_ponds_entry.grid(row=0, column=1, padx=10, pady=10)

correct_detection_label = Label(input_frame, text='Correct Detection:', font=('Arial', 12))
correct_detection_label.grid(row=1, column=0, padx=10, pady=10)
correct_detection_entry = Entry(input_frame)
correct_detection_entry.grid(row=1, column=1, padx=10, pady=10)

incorrect_detection_label = Label(input_frame, text='Incorrect Detection:', font=('Arial', 12))
incorrect_detection_label.grid(row=2, column=0, padx=10, pady=10)
incorrect_detection_entry = Entry(input_frame)
incorrect_detection_entry.grid(row=2, column=1, padx=10, pady=10)

# Create a frame to hold the submit button
button_frame = Frame(window)
button_frame.place(relx=0.77, rely=0.43, relwidth=0.2, relheight=0.2)

# Create the submit button
submit_button = Button(button_frame, text='Submit', command=lambda: next_image(), bg='green', font=('Arial', 16))
submit_button.pack(pady=10)

# Define the maximum number of images to show
MAX_IMAGES = 10

# Define a counter for the number of images shown
num_images_shown = 0

# Function to show the next image
def next_image():
    global shown_images
    global num_images_shown

    if num_images_shown >= MAX_IMAGES:
        finish_survey()
        return

    # Select an image that hasn't been shown yet
    available_images = [path for path in image_paths if path not in shown_images]
    if not available_images:
        messagebox.showerror('Error', 'No more images available.')
        finish_survey()
        return

    image_path = random.choice(available_images)
    shown_images.add(image_path)

    image = Image.open(image_path)
    image = image.resize((620, 500))
    photo = ImageTk.PhotoImage(image)
    label.config(image=photo)
    label.image = photo

    # Record the response
    record_response(image_path, number_ponds_entry.get(), correct_detection_entry.get(), incorrect_detection_entry.get())

    # Clear the entry fields for the next input
    number_ponds_entry.delete(0, 'end')
    correct_detection_entry.delete(0, 'end')
    incorrect_detection_entry.delete(0, 'end')

    # Update the number of images shown
    num_images_shown += 1

def finish_survey():
    welcome_label.config(text='Thank you for participating in our survey!')
    instruction_label.config(text='')
    label.config(image='')
    for widget in input_frame.winfo_children():
        widget.destroy()
    submit_button.config(text='Exit', command=window.quit, bg='red')

# Function to record the response to a CSV file
def record_response(image_path, number_ponds, correct_detection, incorrect_detection):
    image_name = os.path.basename(image_path)

    with open('survey_responses.csv', 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([image_name, number_ponds, correct_detection, incorrect_detection])

# Initialize the GUI and start the survey
next_image()
window.state('zoomed')
window.mainloop()
