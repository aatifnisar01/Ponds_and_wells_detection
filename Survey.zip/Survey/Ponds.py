# -*- coding: utf-8 -*-
"""
Created on Tue Sep 10 11:05:25 2024

@author: Aatif
"""



import csv
import os
import random
from PIL import Image, ImageTk
from tkinter import Tk, Label, Button, Entry, Frame, messagebox

# Path to the folder containing all the images
image_folder = 'C:/Users/Aatif/OneDrive/Desktop/Survey/class0'

# Create a list of image paths from the folder
image_paths = [os.path.join(image_folder, f) for f in os.listdir(image_folder)]

# Keep track of the images that have already been shown
shown_images = set()

# Create the window and label for displaying the images
window = Tk()
window.title('AHI Estimation')

# Add some text to the window
welcome_label = Label(window, text='Welcome to our survey!', font=('Arial', 20))
welcome_label.pack(padx=10, pady=10)
instruction_label = Label(window, text='Please provide the following information for the displayed image:', font=('Arial', 14))
instruction_label.pack(padx=10, pady=10)

# Create a frame to hold the image
image_frame = Frame(window)
image_frame.place(relx=0.01, rely=0.18)

# Create a label for the image
label = Label(image_frame)
label.pack(fill='both', expand=True)

# Create a frame to hold the input fields
input_frame = Frame(window)
input_frame.place(relx=0.58, rely=0.23, relwidth=0.4, relheight=0.8)

# Create input fields
def create_input_field(frame, text, row):
    label = Label(frame, text=text, font=('Arial', 12))
    label.grid(row=row, column=0, padx=10, pady=5, sticky='e')
    entry = Entry(frame)
    entry.grid(row=row, column=1, padx=10, pady=5)
    return entry

number_ponds_entry = create_input_field(input_frame, 'Number of Ponds:', 0)
correct_wet_lined_entry = create_input_field(input_frame, 'Correct (Wet Lined):', 1)
incorrect_wet_lined_entry = create_input_field(input_frame, 'Incorrect (Wet Lined):', 2)
correct_wet_unlined_entry = create_input_field(input_frame, 'Correct (Wet Unlined):', 3)
incorrect_wet_unlined_entry = create_input_field(input_frame, 'Incorrect (Wet Unlined):', 4)
correct_dry_lined_entry = create_input_field(input_frame, 'Correct (Dry Lined):', 5)
incorrect_dry_lined_entry = create_input_field(input_frame, 'Incorrect (Dry Lined):', 6)
correct_dry_unlined_entry = create_input_field(input_frame, 'Correct (Dry Unlined):', 7)
incorrect_dry_unlined_entry = create_input_field(input_frame, 'Incorrect (Dry Unlined):', 8)

# Create a frame to hold the submit button
button_frame = Frame(window)
button_frame.place(relx=0.77, rely=0.85, relwidth=0.2, relheight=0.1)

# Create the submit button
submit_button = Button(button_frame, text='Submit', command=lambda: next_image(), bg='green', font=('Arial', 16))
submit_button.pack(pady=10)

# Define the maximum number of images to show
MAX_IMAGES = 10

# Define a counter for the number of images shown
num_images_shown = 0

# Function to show the next image
def next_image():
    global shown_images
    global num_images_shown

    if num_images_shown >= MAX_IMAGES:
        finish_survey()
        return

    # Select an image that hasn't been shown yet
    available_images = [path for path in image_paths if path not in shown_images]
    if not available_images:
        messagebox.showerror('Error', 'No more images available.')
        finish_survey()
        return

    image_path = random.choice(available_images)
    shown_images.add(image_path)

    image = Image.open(image_path)
    image = image.resize((620, 500))
    photo = ImageTk.PhotoImage(image)
    label.config(image=photo)
    label.image = photo

    # Record the response
    record_response(
        image_path,
        number_ponds_entry.get(),
        correct_wet_lined_entry.get(),
        incorrect_wet_lined_entry.get(),
        correct_wet_unlined_entry.get(),
        incorrect_wet_unlined_entry.get(),
        correct_dry_lined_entry.get(),
        incorrect_dry_lined_entry.get(),
        correct_dry_unlined_entry.get(),
        incorrect_dry_unlined_entry.get()
    )

    # Clear the entry fields for the next input
    for entry in input_frame.winfo_children():
        if isinstance(entry, Entry):
            entry.delete(0, 'end')

    # Update the number of images shown
    num_images_shown += 1

def finish_survey():
    welcome_label.config(text='Thank you for participating in our survey!')
    instruction_label.config(text='')
    label.config(image='')
    for widget in input_frame.winfo_children():
        widget.destroy()
    submit_button.config(text='Exit', command=window.quit, bg='red')

# Function to record the response to a CSV file
def record_response(image_path, number_ponds, correct_wet_lined, incorrect_wet_lined, correct_wet_unlined, incorrect_wet_unlined, correct_dry_lined, incorrect_dry_lined, correct_dry_unlined, incorrect_dry_unlined):
    image_name = os.path.basename(image_path)

    with open('survey_responses.csv', 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([image_name, number_ponds, correct_wet_lined, incorrect_wet_lined, correct_wet_unlined, incorrect_wet_unlined, correct_dry_lined, incorrect_dry_lined, correct_dry_unlined, incorrect_dry_unlined])

# Initialize the GUI and start the survey
next_image()
window.state('zoomed')
window.mainloop()
