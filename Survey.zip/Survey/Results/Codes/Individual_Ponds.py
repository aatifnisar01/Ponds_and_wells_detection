# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 10:50:51 2024

@author: Aatif
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Function to calculate binary truth table
def calculate_binary_truth_table(df):
    # Aggregate correct and incorrect columns
    df['total_correct'] = df.filter(like='_correct').sum(axis=1)
    df['total_incorrect'] = df.filter(like='_incorrect').sum(axis=1)
    
    # Define binary classes
    tp = df['total_correct'].sum()  # True Positives
    fp = df.apply(lambda row: row['total_incorrect'] if row['ponds'] == 0 else max(0, row['total_incorrect'] - row['ponds']), axis=1).sum()  # False Positives
    tn = len(df[(df['ponds'] == 0.0) & (df['total_correct'] == 0.0) & (df['total_incorrect'] == 0.0)])  # True Negatives
    fn = df.apply(lambda row: max(0, row['ponds'] - row['total_correct']), axis=1).sum()  # False Negatives
    return tp, fp, tn, fn

# List of folder names
folder_names = ['badri', 'raman', 'shivani', 'rahul', 'pratham']

# Store truth table results for each folder
truth_tables = {}

# Load and compute truth tables for each folder
for folder in folder_names:
    # Load the data for each folder (update path according to your file structure)
    mohanpur = pd.read_csv(f'C:/Users/Aatif/OneDrive/Desktop/Survey/Results/{folder}/Ponds/survey_responses_{folder}_MohanpurP.csv') 
    masalia = pd.read_csv(f'C:/Users/Aatif/OneDrive/Desktop/Survey/Results/{folder}/Ponds/survey_responses_{folder}_MasaliaP.csv') 
    pindwara = pd.read_csv(f'C:/Users/Aatif/OneDrive/Desktop/Survey/Results/{folder}/Ponds/survey_responses_{folder}_PindwaraP.csv') 
    
    # Fill NaNs with 0 for all
    mohanpur = mohanpur.fillna(0)
    masalia = masalia.fillna(0)
    pindwara = pindwara.fillna(0)
    
    # Calculate TP, FP, TN, FN for each dataset
    tp1, fp1, tn1, fn1 = calculate_binary_truth_table(mohanpur)
    tp2, fp2, tn2, fn2 = calculate_binary_truth_table(masalia)
    tp3, fp3, tn3, fn3 = calculate_binary_truth_table(pindwara)
    
    # Aggregate results for the entire folder
    tp_total = tp1 + tp2 + tp3
    fp_total = fp1 + fp2 + fp3
    tn_total = tn1 + tn2 + tn3
    fn_total = fn1 + fn2 + fn3
    
    # Store truth table for the current folder
    truth_tables[folder] = {'TP': tp_total, 'FP': fp_total, 'TN': tn_total, 'FN': fn_total}

# Calculate average truth table
average_truth_table = {
    'TP': np.mean([truth_tables[folder]['TP'] for folder in folder_names]),
    'FP': np.mean([truth_tables[folder]['FP'] for folder in folder_names]),
    'TN': np.mean([truth_tables[folder]['TN'] for folder in folder_names]),
    'FN': np.mean([truth_tables[folder]['FN'] for folder in folder_names]),
}

# Function to calculate accuracy, precision, and recall
def calculate_metrics(tp, fp, tn, fn):
    accuracy = (tp + tn) / (tp + fp + tn + fn) if (tp + fp + tn + fn) > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    return accuracy, precision, recall

# Function to plot a truth table as a 2x2 matrix with metrics
def plot_truth_table(folder_name, truth_table, ax, show_metrics=True):
    # Define the matrix
    matrix = np.array([[truth_table['TP'], truth_table['FP']],
                       [truth_table['FN'], truth_table['TN']]])
    
    # Calculate metrics
    accuracy, precision, recall = calculate_metrics(
        truth_table['TP'], truth_table['FP'], 
        truth_table['TN'], truth_table['FN']
    )
    
    # Display the matrix
    cax = ax.matshow(matrix, cmap='Blues')
    for (i, j), val in np.ndenumerate(matrix):
        ax.text(j, i, int(val), ha='center', va='center', color='black', fontsize=12)
    
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Positive', 'Negative'])
    ax.set_yticklabels(['Positive', 'Negative'])
    ax.set_title(f"Truth Table for {folder_name}")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    
    # Add colorbar
    plt.colorbar(cax, ax=ax)
    
    # Add metrics as text annotations on the extreme right side of the x-axis
    if show_metrics:
        metrics_text = (
            f'Accuracy: {accuracy:.2f}\n'
            f'Precision: {precision:.2f}\n'
            f'Recall: {recall:.2f}'
        )
        ax.text(1.5, -0.5, metrics_text, ha='left', va='center', fontsize=10, bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.5'), transform=ax.transAxes)

# Plot individual truth tables
for idx, folder in enumerate(folder_names):
    fig, ax = plt.subplots(figsize=(8, 6))
    plot_truth_table(folder, truth_tables[folder], ax)
    plt.tight_layout()
    plt.savefig(f'{folder}_truth_table.png')
    plt.show()

# Plot combined truth tables
fig, axs = plt.subplots(3, 2, figsize=(15, 12))

for idx, folder in enumerate(folder_names):
    ax = axs[idx // 2, idx % 2]
    plot_truth_table(folder, truth_tables[folder], ax, show_metrics=False)  # Don't show metrics in the combined plot

# Plot average truth table
plot_truth_table("Overall/Average", average_truth_table, axs[2, 1])

# Adjust layout and show plot
plt.tight_layout()
plt.savefig('combined_truth_tables.png')
plt.show()

# Plot average truth table separately
fig, ax = plt.subplots(figsize=(8, 6))
plot_truth_table("Overall/Average", average_truth_table, ax)
plt.tight_layout()
plt.savefig('average_truth_table.png')
plt.show()


# =============================================================================
# # Sum the 'correct' columns for each DataFrame
# mohanpur_correct_total = mohanpur[['WL_correct', 'WU_correct', 'DL_correct', 'DU_correct']].sum().sum()
# masalia_correct_total = masalia[['WL_correct', 'WU_correct', 'DL_correct', 'DU_correct']].sum().sum()
# pindwara_correct_total = pindwara[['WL_correct', 'WU_correct', 'DL_correct', 'DU_correct']].sum().sum()
# 
# # Calculate the total number of correct responses across all DataFrames
# total_correct = mohanpur_correct_total + masalia_correct_total + pindwara_correct_total
# 
# 
# # Sum the 'incorrect' columns for each DataFrame
# mohanpur_incorrect_total = mohanpur[['WL_incorrect', 'WU_incorrect', 'DL_incorrect', 'DU_incorrect']].sum().sum()
# masalia_incorrect_total = masalia[['WL_incorrect', 'WU_incorrect', 'DL_incorrect', 'DU_incorrect']].sum().sum()
# pindwara_incorrect_total = pindwara[['WL_incorrect', 'WU_incorrect', 'DL_incorrect', 'DU_incorrect']].sum().sum()
# 
# # Calculate Total Incorrect
# total_incorrect = mohanpur_incorrect_total + masalia_incorrect_total + pindwara_incorrect_total
# 
# 
# # Calculate Completely Incorrect
# # For each DataFrame, sum incorrect values when 'ponds' == 0
# def calculate_completely_incorrect(df):
#     return df[df['ponds'] == 0][['WL_incorrect', 'WU_incorrect', 'DL_incorrect', 'DU_incorrect']].sum().sum()
# 
# completely_incorrect_mohanpur = calculate_completely_incorrect(mohanpur)
# completely_incorrect_masalia = calculate_completely_incorrect(masalia)
# completely_incorrect_pindwara = calculate_completely_incorrect(pindwara)
# 
# 
# 
# # Calculate Misclassified for each DataFrame
# def calculate_misclassified(total_incorrect, completely_incorrect):
#     return total_incorrect - completely_incorrect
# 
# mohanpur_misclassified = calculate_misclassified(mohanpur_incorrect_total, completely_incorrect_mohanpur)
# masalia_misclassified = calculate_misclassified(masalia_incorrect_total, completely_incorrect_masalia)
# pindwara_misclassified = calculate_misclassified(pindwara_incorrect_total, completely_incorrect_pindwara)
# 
# 
# 
# # Calculate accuracy
# accuracy = total_correct / (total_correct + total_incorrect)
# =============================================================================

