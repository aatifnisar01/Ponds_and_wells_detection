# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 10:12:56 2024

@author: Aatif
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Function to calculate truth table
def calculate_multilabel_truth_table(df):
    tp = df['correct'].sum()  # True Positives
    fp = df.apply(lambda row: row['incorrect'] if row['wells'] == 0 else max(0, row['incorrect'] - row['wells']), axis=1).sum()  # False Positives
    tn = len(df[(df['wells'] == 0.0) & (df['correct'] == 0.0) & (df['incorrect'] == 0.0)])  # True Negatives
    fn = df.apply(lambda row: max(0, row['wells'] - row['correct']), axis=1).sum()  # False Negatives
    return tp, fp, tn, fn

# Function to calculate accuracy, precision, and recall
def calculate_metrics(tp, fp, tn, fn):
    accuracy = (tp + tn) / (tp + fp + tn + fn) if (tp + fp + tn + fn) > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    return accuracy, precision, recall

# List of folder names
folder_names = ['badri', 'raman', 'shivani', 'rahul', 'pratham']

# Store truth table results for each folder
truth_tables = {}

# Load and compute truth tables for each folder
for folder in folder_names:
    # Load the data for each folder (update path according to your file structure)
    mohanpur = pd.read_csv(f'C:/Users/Aatif/OneDrive/Desktop/Survey/Results/{folder}/Wells/survey_responses_{folder}_Mohanpur.csv') 
    masalia = pd.read_csv(f'C:/Users/Aatif/OneDrive/Desktop/Survey/Results/{folder}/Wells/survey_responses_{folder}_Masalia.csv') 
    pindwara = pd.read_csv(f'C:/Users/Aatif/OneDrive/Desktop/Survey/Results/{folder}/Wells/survey_responses_{folder}_Pindwara.csv') 
    
    # Fill NaNs with 0 for all
    mohanpur = mohanpur.fillna(0)
    masalia = masalia.fillna(0)
    pindwara = pindwara.fillna(0)
    
    # Calculate TP, FP, TN, FN for each dataset
    tp1, fp1, tn1, fn1 = calculate_multilabel_truth_table(mohanpur)
    tp2, fp2, tn2, fn2 = calculate_multilabel_truth_table(masalia)
    tp3, fp3, tn3, fn3 = calculate_multilabel_truth_table(pindwara)
    
    # Aggregate results for the entire folder
    tp_total = tp1 + tp2 + tp3
    fp_total = fp1 + fp2 + fp3
    tn_total = tn1 + tn2 + tn3
    fn_total = fn1 + fn2 + fn3
    
    # Store truth table for the current folder
    truth_tables[folder] = {'TP': tp_total, 'FP': fp_total, 'TN': tn_total, 'FN': fn_total}

# Calculate average truth table
average_truth_table = {
    'TP': np.mean([truth_tables[folder]['TP'] for folder in folder_names]),
    'FP': np.mean([truth_tables[folder]['FP'] for folder in folder_names]),
    'TN': np.mean([truth_tables[folder]['TN'] for folder in folder_names]),
    'FN': np.mean([truth_tables[folder]['FN'] for folder in folder_names]),
}

# Function to plot a truth table as a 2x2 matrix with metrics
def plot_truth_table(folder_name, truth_table, ax, show_metrics=True):
    # Define the matrix
    matrix = np.array([[truth_table['TP'], truth_table['FP']],
                       [truth_table['FN'], truth_table['TN']]])
    
    # Calculate metrics
    accuracy, precision, recall = calculate_metrics(
        truth_table['TP'], truth_table['FP'], 
        truth_table['TN'], truth_table['FN']
    )
    
    # Display the matrix
    cax = ax.matshow(matrix, cmap='Blues')
    for (i, j), val in np.ndenumerate(matrix):
        ax.text(j, i, int(val), ha='center', va='center', color='black', fontsize=12)
    
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Positive', 'Negative'])
    ax.set_yticklabels(['Positive', 'Negative'])
    ax.set_title(f"Truth Table for {folder_name}")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    
    # Add colorbar
    plt.colorbar(cax, ax=ax)
    
    # Add metrics as text annotations on the extreme right side of the x-axis
    if show_metrics:
        metrics_text = (
            f'Accuracy: {accuracy:.2f}\n'
            f'Precision: {precision:.2f}\n'
            f'Recall: {recall:.2f}'
        )
        ax.text(1.5, -0.5, metrics_text, ha='left', va='center', fontsize=10, bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.5'), transform=ax.transAxes)

# Plot individual truth tables
for idx, folder in enumerate(folder_names):
    fig, ax = plt.subplots(figsize=(8, 6))
    plot_truth_table(folder, truth_tables[folder], ax)
    plt.tight_layout()
    plt.savefig(f'{folder}_truth_table.png')
    plt.show()

# Plot combined truth tables
fig, axs = plt.subplots(3, 2, figsize=(15, 12))

for idx, folder in enumerate(folder_names):
    ax = axs[idx // 2, idx % 2]
    plot_truth_table(folder, truth_tables[folder], ax, show_metrics=False)  # Don't show metrics in the combined plot

# Plot average truth table
plot_truth_table("Overall/Average", average_truth_table, axs[2, 1])

# Adjust layout and show plot
plt.tight_layout()
plt.savefig('combined_truth_tables.png')
plt.show()

# Plot average truth table separately
fig, ax = plt.subplots(figsize=(8, 6))
plot_truth_table("Overall/Average", average_truth_table, ax)
plt.tight_layout()
plt.savefig('average_truth_table.png')
plt.show()







# =============================================================================
# # Calculate total for correct and incorrect columns
# total_correct1 = mohanpur['correct'].sum()
# total_incorrect1 = mohanpur['incorrect'].sum()
# 
# total_correct2 = masalia['correct'].sum()
# total_incorrect2 = masalia['incorrect'].sum()
# 
# total_correct3 = pindwara['correct'].sum()
# total_incorrect3 = pindwara['incorrect'].sum()
# 
# 
# # Calculate overall total correct and incorrect
# overall_correct = total_correct1 + total_correct2 + total_correct3
# overall_incorrect = total_incorrect1 + total_incorrect2 + total_incorrect3
# 
# # Calculate accuracy
# accuracy = overall_correct / (overall_correct + overall_incorrect)
# 
# =============================================================================
